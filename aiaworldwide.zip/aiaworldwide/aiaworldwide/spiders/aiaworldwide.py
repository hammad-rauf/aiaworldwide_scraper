from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor

class AiaworldwideSpider(CrawlSpider):

    name = "aiaworldwide"
    
    start_urls=[]
    
    def __init__(self,  *args, **kwargs):                    
        super(AiaworldwideSpider, self).__init__(*args, **kwargs) 


        file = open("input.txt","r")

        for link in file.readlines():
            link = link.replace("\n","")
            self.start_urls.append(link)

        file.close()

    def parse(self,response):

        links = response.css(".views-table.cols-6 tbody tr .views-field.views-field-title a::attr(href)").extract()
        names = response.css(".views-table.cols-6 tbody tr .views-field.views-field-title a::text").extract()
        cities = response.css("tbody .views-field.views-field-field-city ::text").extract()
        firms = response.css("tbody .views-field.views-field-field-company-name::text").extract()

        print(len(firms))
        print(len(links))
        print(len(names))
        print(len(cities))

        for name,link,city,firm in zip(names,links,cities,firms):

            yield response.follow(url=link,meta={"name":name,"city":city,"firm":firm},callback=self.main_page)


    def main_page(self,response):

        link = response.css(".field.field-name-field-website.field-type-link-field.field-label-inline.clearfix a::attr(href)").extract_first()

        if link:

            yield Request(url=link,meta={"name":response.meta["name"],"city":response.meta["city"],"firm":response.meta["firm"]},callback=self.website)

    
    def website(self,response):

        email = response.css("a[href*='@']::attr(href)").extract_first()

        if email:
            email = email.replace("mailto:","")
            yield{
                "name": response.meta["name"],
                "city":response.meta["city"],
                "email":email,
                "website":response.url,
                "firm":response.meta["firm"]
            }
        else:
            contact_link = response.css("a[href*='contact']::attr(href)").extract_first()

            if contact_link:
                yield response.follow(url=contact_link,meta={"name":response.meta["name"],"city":response.meta["city"],"website":response.url,"firm":response.meta["firm"]},callback=self.contact)
            else:
                contact_link = response.css("a[href*='Contact']::attr(href)").extract_first()
                yield response.follow(url=contact_link,meta={"name":response.meta["name"],"city":response.meta["city"],"website":response.url,"firm":response.meta["firm"]},callback=self.contact)
            
    def contact(self,response):

        email = response.css("a[href*='@']::attr(href)").extract_first()

        if email:
            email = email.replace("mailto:","")
            yield{
                "name": response.meta["name"],
                "city":response.meta["city"],
                "email":email,
                "website":response.meta["website"],
                "firm":response.meta["firm"]
            }



            
